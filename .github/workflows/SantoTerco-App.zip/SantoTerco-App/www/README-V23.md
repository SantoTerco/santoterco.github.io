# Santo Terço — V23 | Edição Universal

A V23 transforma o projeto em uma experiência independente, sem identidade, endereço, contatos ou redes sociais de uma paróquia específica.

## Identidade
- Marca vetorial própria em `assets/images/santo-terco-mark.svg`.
- Nome mantido: Santo Terço.
- Linguagem visual católica, acolhedora e contemplativa, com acabamento refinado.

## Conteúdo e recursos preservados
- Oração do Terço e seleção dos quatro conjuntos de mistérios.
- Referências bíblicas, sínteses meditativas e reflexões.
- Orações tradicionais, configurações, tema escuro e preferências de leitura.
- Leitura em voz alta por meio da síntese de voz disponível no dispositivo.
- Progresso e sequência de oração salvos localmente.

## Mudanças da V23
- Removidos brasão, nome, endereço, horários de Missa, WhatsApp e redes da paróquia original.
- A antiga área de suporte agora apresenta orientações gerais de uso.
- A antiga área de redes agora apresenta informações sobre o aplicativo.
- Removidas referências a futuras gravações de um pároco específico.
- Botão “Ouvir” da biblioteca de orações usa a síntese de voz do dispositivo, quando disponível.

## Observações importantes
- As sínteses meditativas não são transcrições bíblicas. A edição Bíblia Ave-Maria não está reproduzida integralmente.
- A disponibilidade de vozes varia conforme o aparelho e navegador.
- Teste as telas e os recursos em diferentes dispositivos antes de distribuir publicamente.
- Esta edição ainda não é um APK compilado.
