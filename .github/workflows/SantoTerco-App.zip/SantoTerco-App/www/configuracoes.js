/* ================================================================
   CONFIGURACOES.JS — PREFERÊNCIAS DO USUÁRIO
   ---------------------------------------------------------------
   Este arquivo controla as opções da página Configurações.
   Os dados ficam no localStorage, portanto continuam salvos mesmo
   quando o usuário fecha o navegador/app.
   ================================================================ */

// Valores usados quando o usuário ainda não escolheu nada.
const defaults = {
  theme: "auto",
  beadSound: true,
  animations: true,
  confirmAdvance: false,
  skipCross: false,
  saveProgress: true,
  textSize: "normal",
  volume: 22,
  voiceURI: "",
  voiceRate: 0.9
};

// Lê as configurações atuais e completa qualquer item que esteja faltando.
function loadSettings() {
  const saved = JSON.parse(
    localStorage.getItem("santoTercoSettings") || "{}"
  );

  return { ...defaults, ...saved };
}

// Salva as configurações e imediatamente aplica o resultado na página.
function saveSettings(settings) {
  localStorage.setItem(
    "santoTercoSettings",
    JSON.stringify(settings)
  );

  applySettings(settings);
}

// Aplica as classes que o CSS usa para mudar aparência e animações.
function applySettings(settings) {
  const root = document.documentElement;

  // Guarda também o tema como atributo; isso facilita futuras personalizações.
  root.dataset.theme = settings.theme;

  // O tamanho do texto também é aplicado na própria tela de Configurações.
  root.dataset.textSize = settings.textSize || "normal";

  // Liga/desliga a classe de redução de movimento.
  root.classList.toggle("reduce-motion", !settings.animations);

  // Somente um dos temas forçados pode estar ativo por vez.
  root.classList.toggle("forced-dark", settings.theme === "dark");
  root.classList.toggle("forced-light", settings.theme === "light");
}

// Carrega o estado inicial.
const settings = loadSettings();
applySettings(settings);

// Referências aos controles da página.
const themeSelect = document.getElementById("theme-setting");
const beadSoundInput = document.getElementById("bead-sound");
const animationsInput = document.getElementById("animations");
const confirmAdvanceInput = document.getElementById("confirm-advance");
const skipCrossInput = document.getElementById("skip-cross");
const saveProgressInput = document.getElementById("save-progress");
const textSizeSelect = document.getElementById("text-size");
const volumeInput = document.getElementById("volume-setting");
const volumeValue = document.getElementById("volume-value");
const resetButton = document.getElementById("reset-settings");
const clearProgressButton = document.getElementById("clear-progress");

// Coloca na interface os valores atualmente salvos.
themeSelect.value = settings.theme;
beadSoundInput.checked = settings.beadSound;
animationsInput.checked = settings.animations;
confirmAdvanceInput.checked = settings.confirmAdvance;
skipCrossInput.checked = settings.skipCross;
saveProgressInput.checked = settings.saveProgress;
textSizeSelect.value = settings.textSize;
volumeInput.value = settings.volume;
volumeValue.textContent = `${settings.volume}%`;

// Lista dos campos e da propriedade correspondente no objeto settings.
const fields = [
  [themeSelect, "theme"],
  [beadSoundInput, "beadSound"],
  [animationsInput, "animations"],
  [confirmAdvanceInput, "confirmAdvance"],
  [skipCrossInput, "skipCross"],
  [saveProgressInput, "saveProgress"],
  [textSizeSelect, "textSize"],
  [volumeInput, "volume"]
];

// Sempre que o usuário alterar uma opção, atualizamos e salvamos.
fields.forEach(([element, key]) => {
  const update = (event) => {
    settings[key] =
      event.target.type === "checkbox"
        ? event.target.checked
        : event.target.type === "range"
          ? Number(event.target.value)
          : event.target.value;

    if (key === "volume") volumeValue.textContent = `${settings.volume}%`;
    if (key === "saveProgress" && settings.saveProgress === false) {
      localStorage.removeItem("santoTercoProgress");
    }
    saveSettings(settings);
  };

  // O volume atualiza o número enquanto o dedo desliza.
  element.addEventListener(element.type === "range" ? "input" : "change", update);
  if (element.type === "range") element.addEventListener("change", update);
});


// Apaga somente o ponto salvo do Terço, sem alterar as demais configurações.
clearProgressButton.addEventListener("click", () => {
  if (!localStorage.getItem("santoTercoProgress")) {
    alert("Não há progresso salvo para apagar.");
    return;
  }
  if (!confirm("Apagar o ponto salvo do Terço? Esta ação não altera suas outras configurações.")) return;
  localStorage.removeItem("santoTercoProgress");
  alert("O progresso salvo do Terço foi apagado.");
});

// Restaura tudo para o padrão definido no começo deste arquivo.
resetButton.addEventListener("click", () => {
  if (!confirm("Restaurar todas as configurações para os valores padrão?")) return;
  Object.assign(settings, defaults);
  saveSettings(settings);

  themeSelect.value = settings.theme;
  beadSoundInput.checked = settings.beadSound;
  animationsInput.checked = settings.animations;
  confirmAdvanceInput.checked = settings.confirmAdvance;
skipCrossInput.checked = settings.skipCross;
saveProgressInput.checked = settings.saveProgress;
textSizeSelect.value = settings.textSize;
volumeInput.value = settings.volume;
volumeValue.textContent = `${settings.volume}%`;
  if (voiceSelect) {
    refreshVoiceOptions();
    voiceSelect.value = settings.voiceURI || "";
    voiceRateSelect.value = String(settings.voiceRate || 0.9);
  }
});


// V19.2 — vozes fornecidas pelo navegador/dispositivo (Web Speech API).
const voiceSelect = document.getElementById("voice-setting");
const voiceRateSelect = document.getElementById("voice-rate");
const testVoiceButton = document.getElementById("test-voice");
const stopVoiceButton = document.getElementById("stop-voice");

function refreshVoiceOptions() {
  if (!voiceSelect || !("speechSynthesis" in window)) return;
  const oldValue = settings.voiceURI || "";
  const voices = window.speechSynthesis.getVoices().filter(v => /^pt([_-]|$)/i.test(v.lang));
  voiceSelect.innerHTML = '<option value="">Voz padrão do dispositivo</option>';
  voices.forEach((voice, index) => {
    const option = document.createElement("option");
    option.value = voice.voiceURI;
    option.textContent = `${voice.name} — ${voice.lang}${voice.default ? " (padrão)" : ""}`;
    voiceSelect.appendChild(option);
  });
  if ([...voiceSelect.options].some(o => o.value === oldValue)) voiceSelect.value = oldValue;
  else voiceSelect.value = "";
}
if (voiceSelect) {
  voiceSelect.value = settings.voiceURI || "";
  voiceRateSelect.value = String(settings.voiceRate || 0.9);
  refreshVoiceOptions();
  if ("speechSynthesis" in window) window.speechSynthesis.addEventListener?.("voiceschanged", refreshVoiceOptions);
  voiceSelect.addEventListener("change", () => { settings.voiceURI = voiceSelect.value; saveSettings(settings); });
  voiceRateSelect.addEventListener("change", () => { settings.voiceRate = Number(voiceRateSelect.value); saveSettings(settings); });
}
if (testVoiceButton) testVoiceButton.addEventListener("click", () => {
  if (!("speechSynthesis" in window)) { alert("A leitura em voz alta não está disponível neste navegador."); return; }
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance("Ave Maria, cheia de graça, o Senhor é convosco.");
  u.lang = "pt-BR"; u.rate = Number(settings.voiceRate || 0.9);
  const chosen = window.speechSynthesis.getVoices().find(v => v.voiceURI === settings.voiceURI) || window.speechSynthesis.getVoices().find(v => /^pt[-_]BR$/i.test(v.lang)) || window.speechSynthesis.getVoices().find(v => /^pt/i.test(v.lang));
  if (chosen) u.voice = chosen;
  window.speechSynthesis.speak(u);
});
if (stopVoiceButton) stopVoiceButton.addEventListener("click", () => { if ("speechSynthesis" in window) window.speechSynthesis.cancel(); alert("Leitura em voz alta interrompida."); });
