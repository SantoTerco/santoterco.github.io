const days={0:{name:'Mistérios Gloriosos',color:'#7696B4',dark:'#4E6D8A',soft:'#DDE7F0',pale:'#F0F5F9'},1:{name:'Mistérios Gozosos',color:'#87A98A',dark:'#52775A',soft:'#DFEADF',pale:'#F1F7F1'},2:{name:'Mistérios Dolorosos',color:'#9B7182',dark:'#765161',soft:'#EEE3E7',pale:'#F8F1F4'},3:{name:'Mistérios Gloriosos',color:'#7696B4',dark:'#4E6D8A',soft:'#DDE7F0',pale:'#F0F5F9'},4:{name:'Mistérios Luminosos',color:'#D6B45D',dark:'#927A32',soft:'#F2E8C9',pale:'#FBF7EA'},5:{name:'Mistérios Dolorosos',color:'#9B7182',dark:'#765161',soft:'#EEE3E7',pale:'#F8F1F4'},6:{name:'Mistérios Gozosos',color:'#87A98A',dark:'#52775A',soft:'#DFEADF',pale:'#F1F7F1'}};
const theme=days[new Date().getDay()];
const settings=JSON.parse(localStorage.getItem('santoTercoSettings')||'{}');
const savedProgress=JSON.parse(localStorage.getItem('santoTercoProgress')||'null');
if(savedProgress?.state){
  location.replace('terco.html');
  throw new Error('Abrindo o progresso salvo do Santo Terço.');
}
if(settings.skipCross===true){
  location.replace('credo.html');
  throw new Error('Sinal da Cruz inicial desativado nas configurações.');
}
for(const [k,v] of Object.entries({'--mystery':theme.color,'--mystery-dark':theme.dark,'--mystery-soft':theme.soft,'--mystery-pale':theme.pale}))document.documentElement.style.setProperty(k,v);
const $=id=>document.getElementById(id);
let last=null,gesture=[],resetTimer=null;const expected=['up','right','left','down'];
function dir(dx,dy){if(Math.max(Math.abs(dx),Math.abs(dy))<30)return null;return Math.abs(dx)>=Math.abs(dy)?(dx>0?'right':'left'):(dy>0?'down':'up')}
function updateGestureUI(){
  document.querySelectorAll('.gesture-dot').forEach((x,i)=>x.classList.toggle('active',i<gesture.length));
  const n=gesture.length;
  $('gesture-status').textContent=n===0?'Comece em qualquer ponto da tela':n<4?`${n} de 4 movimentos`:'Sinal da Cruz concluído';
  $('sign-instruction').textContent=n===0?'Deslize seguindo a sequência abaixo.':n<4?'Continue com calma, seguindo a próxima direção.':'Muito bem.';
}
function resetGesture(){gesture=[];updateGestureUI();}
function move(e){
  if(!last)return;
  const d=dir(e.clientX-last.x,e.clientY-last.y);
  if(!d)return;
  last={x:e.clientX,y:e.clientY};
  if(gesture.length>=4)return;
  if(d===expected[gesture.length]){
    clearTimeout(resetTimer);
    gesture.push(d);
    updateGestureUI();
    const arm=$('intro-cross').querySelectorAll('span')[gesture.length-1];
    if(arm)arm.classList.add('gesture-hit');
    if(gesture.length===4){
      $('intro-cross').classList.add('done');
      sessionStorage.setItem('tercoThemeDay',String(new Date().getDay()));
      setTimeout(()=>location.href='credo.html',560);
    }
  }else{
    $('sign-card').classList.remove('gesture-error');void $('sign-card').offsetWidth;$('sign-card').classList.add('gesture-error');
    clearTimeout(resetTimer);resetTimer=setTimeout(()=>{resetGesture();$('sign-card').classList.remove('gesture-error')},650);
  }
}
// O gesto continua sendo global: pode começar literalmente em qualquer ponto da tela.
document.addEventListener('pointerdown',e=>{if(e.target.closest('a,button'))return;clearTimeout(resetTimer);last={x:e.clientX,y:e.clientY};document.body.style.touchAction='none'},{passive:false});
document.addEventListener('pointermove',e=>{if(!last)return;e.preventDefault();move(e)},{passive:false});
document.addEventListener('pointerup',()=>{last=null;document.body.style.touchAction='auto'});
document.addEventListener('pointercancel',()=>{last=null;document.body.style.touchAction='auto'});
updateGestureUI();
