/* HOME — estado do botão principal do Santo Terço.
   Prioridade: continuar uma oração em andamento; se não houver progresso,
   indicar quando o Terço já foi concluído hoje. */
(function(){
  const button=document.querySelector('#main-prayer-action');
  const again=document.querySelector('#pray-again-link');
  if(!button) return;

  const description=document.querySelector('.main-action p:not(.action-kicker)');
  const readJSON=(key,fallback)=>{
    try{return JSON.parse(localStorage.getItem(key) || JSON.stringify(fallback));}
    catch(e){return fallback;}
  };
  const settings=readJSON('santoTercoSettings',{});
  const progress=readJSON('santoTercoProgress',null);

  const now=new Date();
  const today=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
  const prayedDays=readJSON('santoTercoPrayedDays',[]);
  const completedToday=Array.isArray(prayedDays) && prayedDays.includes(today);

  if(settings.saveProgress !== false && progress?.state){
    button.href='terco.html';
    button.innerHTML='Continuar <span>→</span>';
    if(description) description.textContent='Continue exatamente de onde você parou.';
    if(again) again.hidden=true;
    return;
  }

  if(completedToday){
    button.removeAttribute('href');
    button.removeAttribute('role');
    button.setAttribute('aria-disabled','true');
    button.classList.add('is-completed');
    button.innerHTML='Concluído <span>✓</span>';
    if(description) description.textContent='Você já concluiu seu Santo Terço hoje. Que sua oração continue dando frutos.';
    if(again) again.hidden=false;
  }else if(again){
    again.hidden=true;
  }
})();
