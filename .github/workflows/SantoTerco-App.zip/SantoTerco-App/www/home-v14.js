/* HOME-V14 — decide se o botão principal deve começar ou continuar. */
(function(){
  const button=document.querySelector('.main-action .primary-button');
  if(!button) return;
  const settings=JSON.parse(localStorage.getItem('santoTercoSettings')||'{}');
  const progress=JSON.parse(localStorage.getItem('santoTercoProgress')||'null');
  if(settings.saveProgress !== false && progress?.state){
    button.href='terco.html';
    button.innerHTML='Continuar <span>→</span>';
    const description=document.querySelector('.main-action p:not(.action-kicker)');
    if(description) description.textContent='Continue exatamente de onde você parou.';
  }
})();
