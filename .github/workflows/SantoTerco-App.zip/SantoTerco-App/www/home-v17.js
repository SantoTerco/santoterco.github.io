/* ================================================================
   V17 — CAMINHADA DE ORAÇÃO
   Registra os dias em que o fiel concluiu pelo menos um Terço e
   mostra a semana atual + a sequência consecutiva.
   ================================================================ */
(function prayerStreak(){
  const host=document.getElementById('prayer-streak');
  if(!host) return;

  const key='santoTercoPrayedDays';
  let prayed=[];
  try{ prayed=JSON.parse(localStorage.getItem(key)||'[]'); }catch(e){ prayed=[]; }
  if(!Array.isArray(prayed)) prayed=[];
  const prayedSet=new Set(prayed);

  const dateKey=(d)=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const startOfDay=(d)=>new Date(d.getFullYear(),d.getMonth(),d.getDate());
  const today=startOfDay(new Date());

  // A sequência conta somente dias consecutivos terminando hoje.
  let streak=0;
  for(let i=0;;i++){
    const d=new Date(today); d.setDate(today.getDate()-i);
    if(!prayedSet.has(dateKey(d))) break;
    streak++;
  }

  const flameLevel=streak<=0?0:streak<=7?1:streak<=15?2:streak<=30?3:streak<=50?4:streak<=75?5:6;
  const flame='🔥'.repeat(Math.max(1,flameLevel));
  const names=['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
  const weekStart=new Date(today); weekStart.setDate(today.getDate()-today.getDay());

  const daysHtml=names.map((name,i)=>{
    const d=new Date(weekStart); d.setDate(weekStart.getDate()+i);
    const done=prayedSet.has(dateKey(d));
    const isToday=dateKey(d)===dateKey(today);
    return `<div class="streak-day${done?' done':''}${isToday?' today':''}" aria-label="${name}${done?' — Terço rezado':''}">
      <span>${name}</span><strong>${done?'✓':'·'}</strong>
    </div>`;
  }).join('');

  host.innerHTML=`
    <div class="streak-head">
      <div><span class="section-label">Sua caminhada</span><h2>Semana de oração</h2></div>
      <div class="streak-count">${streak}<small>${streak===1?'dia':'dias'}</small></div>
    </div>
    <div class="streak-flame ${flameLevel?'active':''}" aria-label="Sequência de ${streak} ${streak===1?'dia':'dias'}">${flameLevel?flame:'🤍'}</div>
    <div class="streak-message">${streak>0?'Continue sua caminhada de oração.':'Comece hoje sua caminhada de oração.'}</div>
    <div class="streak-week">${daysHtml}</div>
    <small class="streak-note">Conta um dia quando você conclui pelo menos um Santo Terço.</small>
  `;
})();
