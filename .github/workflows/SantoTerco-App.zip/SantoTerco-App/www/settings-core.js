/* ================================================================
   SETTINGS-CORE.JS — APLICAÇÃO GLOBAL DAS PREFERÊNCIAS
   ---------------------------------------------------------------
   Este arquivo é carregado em várias páginas. Ele NÃO desenha a tela;
   apenas lê o que foi salvo em localStorage e aplica classes no <html>.
   Assim, o tema funciona mesmo quando o usuário muda de página.
   ================================================================ */

(function applySavedSettings() {
  // Tenta ler as configurações. Se não existir nada salvo, usa um objeto vazio.
  const settings = JSON.parse(localStorage.getItem("santoTercoSettings") || "{}");

  // Tema escuro escolhido manualmente pelo usuário.
  document.documentElement.classList.toggle(
    "forced-dark",
    settings.theme === "dark"
  );

  // Tema claro escolhido manualmente pelo usuário.
  document.documentElement.classList.toggle(
    "forced-light",
    settings.theme === "light"
  );

  // Tamanho de texto escolhido pelo fiel.
  document.documentElement.dataset.textSize = settings.textSize || "normal";

  // Quando as animações estão desligadas, o CSS reduz todas as transições.
  document.documentElement.classList.toggle(
    "reduce-motion",
    settings.animations === false
  );
})();
