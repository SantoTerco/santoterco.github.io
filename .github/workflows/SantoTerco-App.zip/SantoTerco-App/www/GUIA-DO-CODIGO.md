# Guia do código — Santo Terço V23

Este guia descreve a edição universal do aplicativo.

## Estrutura principal
- `index.html`: página inicial e navegação.
- `terco.html`, `rezar.html`, `terco.js`, `rezar.css`: fluxo de oração.
- `outros-misterios.html` e `outros-misterios.js`: seleção dos mistérios.
- `oracoes.html` e `oracoes.js`: biblioteca de orações e leitura em voz alta.
- `configuracoes.html`, `configuracoes.js`, `settings-core.js`: preferências, tema, voz e acessibilidade.
- `suporte.html`: ajuda e orientações gerais.
- `redes.html`: informações sobre o aplicativo.
- `style.css` e `extras.css`: identidade visual e componentes.
- `assets/images/`: imagens dos mistérios e marca universal.
- `assets/audio/conta-madeira.wav`: som opcional das contas.

## Identidade visual
A marca vetorial está em `assets/images/santo-terco-mark.svg`. As cores e os componentes gerais ficam em `style.css`; os acabamentos das páginas internas ficam em `extras.css`.

## Recursos de voz
A leitura das orações usa `SpeechSynthesis` do navegador/dispositivo. A lista de vozes disponíveis depende do sistema operacional e do navegador.

## Leituras bíblicas
As referências e sínteses meditativas ficam em `terco.js`. As sínteses são textos de apoio e não substituem a Bíblia. Não inserir transcrição de tradução protegida por direitos autorais sem autorização.

## Testes recomendados
1. Abrir `index.html` em um navegador móvel.
2. Percorrer todas as etapas do Terço e testar voltar/avançar.
3. Abrir os quatro conjuntos de mistérios.
4. Testar mostrar/ocultar leitura e reflexão.
5. Testar leitura em voz alta e interrompê-la ao navegar.
6. Testar tema claro, escuro e automático.
7. Testar configurações, progresso salvo e sequência diária.
8. Testar todas as páginas em telas estreitas.

A V23 ainda é um projeto web e não um APK compilado.
