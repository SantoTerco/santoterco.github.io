/* ================================================================
   SCRIPT.JS — MISTÉRIO DO DIA NA HOME
   Este arquivo descobre o dia da semana e atualiza nome, símbolo e cores.
   ================================================================ */
const mysteryByDay = {
  0: {
    name: "Mistérios Gloriosos",
    color: "#7696B4",
    dark: "#4E6D8A",
    soft: "#DDE7F0",
    pale: "#F0F5F9",
    symbol: "✦"
  },
  1: {
    name: "Mistérios Gozosos",
    color: "#87A98A",
    dark: "#52775A",
    soft: "#DFEADF",
    pale: "#F1F7F1",
    symbol: "✿"
  },
  2: {
    name: "Mistérios Dolorosos",
    color: "#9B7182",
    dark: "#765161",
    soft: "#EEE3E7",
    pale: "#F8F1F4",
    symbol: "✝"
  },
  3: {
    name: "Mistérios Gloriosos",
    color: "#7696B4",
    dark: "#4E6D8A",
    soft: "#DDE7F0",
    pale: "#F0F5F9",
    symbol: "✦"
  },
  4: {
    name: "Mistérios Luminosos",
    color: "#D6B45D",
    dark: "#927A32",
    soft: "#F2E8C9",
    pale: "#FBF7EA",
    symbol: "☀"
  },
  5: {
    name: "Mistérios Dolorosos",
    color: "#9B7182",
    dark: "#765161",
    soft: "#EEE3E7",
    pale: "#F8F1F4",
    symbol: "✝"
  },
  6: {
    name: "Mistérios Gozosos",
    color: "#87A98A",
    dark: "#52775A",
    soft: "#DFEADF",
    pale: "#F1F7F1",
    symbol: "✿"
  }
};

const root = document.documentElement;
const dateText = document.getElementById("date-text");
const mysteryName = document.getElementById("mystery-name");
const mysterySymbol = document.getElementById("mystery-symbol");

function applyTodayMystery() {
  const today = new Date();
  const mystery = mysteryByDay[today.getDay()];

  const formattedDate = new Intl.DateTimeFormat("pt-BR", {
    weekday: "long",
    day: "numeric",
    month: "long"
  }).format(today);

  dateText.textContent =
    formattedDate.charAt(0).toUpperCase() + formattedDate.slice(1);

  mysteryName.textContent = mystery.name;
  mysterySymbol.textContent = mystery.symbol;

  root.style.setProperty("--mystery", mystery.color);
  root.style.setProperty("--mystery-dark", mystery.dark);
  root.style.setProperty("--mystery-soft", mystery.soft);
  root.style.setProperty("--mystery-pale", mystery.pale);
  document.querySelector('meta[name="theme-color"]')
    .setAttribute("content", mystery.color);

  // Deixa a regra visível no console durante o desenvolvimento.
  console.log(`Hoje: ${mystery.name}`);
}

applyTodayMystery();
