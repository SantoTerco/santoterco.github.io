// Santo Terço - funcionamento offline
const BUILD = '__BUILD__';
const CACHE = 'santo-terco-' + BUILD;
const FONT_CSS = 'https://fonts.googleapis.com/css2?family=Comfortaa:wght@400;500;600;700&family=Libre+Baskerville:wght@400;700&display=swap';
const FILES = ["./", "./assets/audio/conta-madeira.wav", "./assets/icons/apple-touch-icon.png", "./assets/icons/icon-192.png", "./assets/icons/icon-512.png", "./assets/icons/maskable-512.png", "./assets/images/credo-frame.webp", "./assets/images/credo.webp", "./assets/images/dolorosos-1-agonia.webp", "./assets/images/dolorosos-2-flagelacao.webp", "./assets/images/dolorosos-3-coroacao.webp", "./assets/images/dolorosos-4-cruz.webp", "./assets/images/dolorosos-5-crucificacao.webp", "./assets/images/framed/dolorosos-1-agonia-frame.webp", "./assets/images/framed/dolorosos-2-flagelacao-frame.webp", "./assets/images/framed/dolorosos-3-coroacao-frame.webp", "./assets/images/framed/dolorosos-4-cruz-frame.webp", "./assets/images/framed/dolorosos-5-crucificacao-frame.webp", "./assets/images/framed/gloriosos-1-ressurreicao-frame.webp", "./assets/images/framed/gloriosos-2-ascensao-frame.webp", "./assets/images/framed/gloriosos-3-pentecostes-frame.webp", "./assets/images/framed/gloriosos-4-assuncao-frame.webp", "./assets/images/framed/gloriosos-5-coroacao-frame.webp", "./assets/images/framed/gozosos-1-anunciacao-frame.webp", "./assets/images/framed/gozosos-2-visitacao-frame.webp", "./assets/images/framed/gozosos-3-nascimento-frame.webp", "./assets/images/framed/gozosos-4-apresentacao-frame.webp", "./assets/images/framed/gozosos-5-encontro-frame.webp", "./assets/images/framed/luminosos-1-batismo-frame.webp", "./assets/images/framed/luminosos-2-bodas-frame.webp", "./assets/images/framed/luminosos-3-reino-frame.webp", "./assets/images/framed/luminosos-4-transfiguracao-frame.webp", "./assets/images/framed/luminosos-5-eucaristia-frame.webp", "./assets/images/framed/o-meu-jesus-frame.webp", "./assets/images/framed/salve-rainha-frame.webp", "./assets/images/gloriosos-1-ressurreicao.webp", "./assets/images/gloriosos-2-ascensao.webp", "./assets/images/gloriosos-3-pentecostes.webp", "./assets/images/gloriosos-4-assuncao.webp", "./assets/images/gloriosos-5-coroacao.webp", "./assets/images/gozosos-1-anunciacao.webp", "./assets/images/gozosos-2-visitacao.webp", "./assets/images/gozosos-3-nascimento.webp", "./assets/images/gozosos-4-apresentacao.webp", "./assets/images/gozosos-5-encontro.webp", "./assets/images/luminosos-1-batismo.webp", "./assets/images/luminosos-2-bodas.webp", "./assets/images/luminosos-3-reino.webp", "./assets/images/luminosos-4-transfiguracao.webp", "./assets/images/luminosos-5-eucaristia.webp", "./assets/images/o-meu-jesus.webp", "./assets/images/ostensorio-ihs.svg", "./assets/images/salve-rainha.webp", "./assets/images/santo-terco-mark.svg", "./configuracoes.html", "./configuracoes.js", "./credo.html", "./credo.js", "./extras.css", "./home-v14.js", "./home-v17.js", "./index.html", "./inicio.js", "./manifest.webmanifest", "./oracoes.html", "./oracoes.js", "./outros-misterios.html", "./outros-misterios.js", "./pwa-register.js", "./redes.html", "./rezar.css", "./rezar.html", "./script.js", "./settings-core.js", "./style.css", "./suporte.html", "./terco.html", "./terco.js"];

self.addEventListener('install', function (e) {
  e.waitUntil((async function () {
    const c = await caches.open(CACHE);
    await Promise.all(FILES.map(function (f) { return c.add(new Request(f, { cache: 'reload' })).catch(function () {}); }));
    try {
      const r = await fetch(FONT_CSS);
      const css = await r.clone().text();
      await c.put(FONT_CSS, r);
      const urls = Array.from(css.matchAll(/url\((https:[^)]+)\)/g)).map(function (m) { return m[1]; });
      await Promise.all(urls.map(function (u) { return fetch(u).then(function (x) { return c.put(u, x); }).catch(function () {}); }));
    } catch (err) {}
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', function (e) {
  e.waitUntil((async function () {
    const keys = await caches.keys();
    await Promise.all(keys.filter(function (k) { return k.indexOf('santo-terco-') === 0 && k !== CACHE; }).map(function (k) { return caches.delete(k); }));
    await self.clients.claim();
  })());
});

async function rangeResponse(req, res) {
  const m = /bytes=(\d*)-(\d*)/.exec(req.headers.get('range'));
  const buf = await res.arrayBuffer();
  const size = buf.byteLength;
  let s = m && m[1] ? parseInt(m[1], 10) : 0;
  let en = m && m[2] ? parseInt(m[2], 10) : size - 1;
  if (en >= size) en = size - 1;
  return new Response(buf.slice(s, en + 1), {
    status: 206, statusText: 'Partial Content',
    headers: {
      'Content-Type': res.headers.get('Content-Type') || 'application/octet-stream',
      'Content-Range': 'bytes ' + s + '-' + en + '/' + size,
      'Content-Length': String(en - s + 1)
    }
  });
}

self.addEventListener('fetch', function (e) {
  const req = e.request;
  if (req.method !== 'GET') return;
  e.respondWith((async function () {
    const sameOrigin = new URL(req.url).origin === self.location.origin;
    let hit = await caches.match(req, { ignoreVary: true, ignoreSearch: sameOrigin });
    if (hit) {
      if (req.headers.has('range') && hit.status === 200) return rangeResponse(req, hit);
      return hit;
    }
    try {
      const res = await fetch(req);
      if (res && (res.status === 200 || res.type === 'opaque') && !req.headers.has('range')) {
        const c = await caches.open(CACHE);
        c.put(req, res.clone());
      }
      return res;
    } catch (err) {
      if (req.mode === 'navigate') {
        const fb = await caches.match('./index.html');
        if (fb) return fb;
      }
      throw err;
    }
  })());
});
