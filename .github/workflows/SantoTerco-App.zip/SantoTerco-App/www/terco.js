/* ================================================================
   TERCO.JS — FLUXO PRINCIPAL DO SANTO TERÇO — V20
   ---------------------------------------------------------------
   A V14 transforma o progresso do Terço em um estado completo.
   Assim o app consegue:
   • voltar exatamente para a oração anterior;
   • salvar o ponto onde o fiel parou;
   • continuar depois de fechar o app;
   • sair para a Home perguntando se deseja guardar o progresso.
   ================================================================ */

const DATA = {
  0:{name:'Mistérios Gloriosos',color:'#7696B4',dark:'#4E6D8A',soft:'#DDE7F0',pale:'#F0F5F9',key:'gloriosos',m:[['A Ressurreição de Jesus','Jo 20, 1-18'],['A Ascensão de Jesus ao Céu','At 1, 6-11'],['A Vinda do Espírito Santo','At 2, 1-4'],['A Assunção de Nossa Senhora','Lc 1, 46-55 (meditação mariana relacionada)'],['A Coroação de Nossa Senhora','Ap 12, 1-6 (meditação mariana relacionada)']]},
  1:{name:'Mistérios Gozosos',color:'#87A98A',dark:'#52775A',soft:'#DFEADF',pale:'#F1F7F1',key:'gozosos',m:[['A Anunciação do Anjo a Maria','Lc 1, 26-38'],['A Visitação de Maria a Isabel','Lc 1, 39-45'],['O Nascimento de Jesus','Lc 2, 1-7'],['A Apresentação de Jesus no Templo','Lc 2, 22-35'],['A Perda e o Encontro de Jesus no Templo','Lc 2, 41-52']]},
  2:{name:'Mistérios Dolorosos',color:'#9B7182',dark:'#765161',soft:'#EEE3E7',pale:'#F8F1F4',key:'dolorosos',m:[['A Agonia de Jesus no Horto','Lc 22, 39-46'],['A Flagelação de Jesus','Jo 19, 1'],['A Coroação de Espinhos','Mt 27, 27-31'],['Jesus carrega a Cruz','Jo 19, 16-17'],['A Crucificação e Morte de Jesus','Jo 19, 25-30']]},
  3:{name:'Mistérios Gloriosos',color:'#7696B4',dark:'#4E6D8A',soft:'#DDE7F0',pale:'#F0F5F9',key:'gloriosos',m:[['A Ressurreição de Jesus','Jo 20, 1-18'],['A Ascensão de Jesus ao Céu','At 1, 6-11'],['A Vinda do Espírito Santo','At 2, 1-4'],['A Assunção de Nossa Senhora','Lc 1, 46-55 (meditação mariana relacionada)'],['A Coroação de Nossa Senhora','Ap 12, 1-6 (meditação mariana relacionada)']]},
  4:{name:'Mistérios Luminosos',color:'#D6B45D',dark:'#927A32',soft:'#F2E8C9',pale:'#FBF7EA',key:'luminosos',m:[['O Batismo de Jesus no Jordão','Mt 3, 13-17'],['As Bodas de Caná','Jo 2, 1-11'],['O Anúncio do Reino de Deus','Mc 1, 14-15'],['A Transfiguração de Jesus','Mt 17, 1-8'],['A Instituição da Eucaristia','Lc 22, 14-20']]},
  5:{name:'Mistérios Dolorosos',color:'#9B7182',dark:'#765161',soft:'#EEE3E7',pale:'#F8F1F4',key:'dolorosos',m:[['A Agonia de Jesus no Horto','Lc 22, 39-46'],['A Flagelação de Jesus','Jo 19, 1'],['A Coroação de Espinhos','Mt 27, 27-31'],['Jesus carrega a Cruz','Jo 19, 16-17'],['A Crucificação e Morte de Jesus','Jo 19, 25-30']]},
  6:{name:'Mistérios Gozosos',color:'#87A98A',dark:'#52775A',soft:'#DFEADF',pale:'#F1F7F1',key:'gozosos',m:[['A Anunciação do Anjo a Maria','Lc 1, 26-38'],['A Visitação de Maria a Isabel','Lc 1, 39-45'],['O Nascimento de Jesus','Lc 2, 1-7'],['A Apresentação de Jesus no Templo','Lc 2, 22-35'],['A Perda e o Encontro de Jesus no Templo','Lc 2, 41-52']]}
};

/* ================================================================
   V20 — REFERÊNCIAS E LEITURAS PARA MEDITAÇÃO
   ---------------------------------------------------------------
   Cada mistério possui:
   • referência bíblica para quem prefere usar sua Bíblia física;
   • síntese original da passagem (não substitui a Bíblia);
   • reflexão curta para oração pessoal;
   • reflexões em texto para acompanhar a oração.

   A síntese não substitui a leitura bíblica integral. Para reproduzir
   uma tradução protegida, é necessária autorização do titular dos direitos.
   ================================================================ */
const meditationData = {
  gozosos: [
    { reading:'Lc 1, 26-38', summary:'Maria recebe o anúncio do anjo e, com confiança, acolhe a vontade de Deus. Sua resposta abre espaço para a encarnação de Jesus.', reflection:'Como Maria, procure acolher hoje a vontade de Deus com confiança, mesmo quando você ainda não conhece todos os caminhos.' },
    { reading:'Lc 1, 39-45', summary:'Maria visita Isabel e leva consigo a presença de Jesus. O encontro se transforma em alegria, serviço e louvor a Deus.', reflection:'Quem precisa receber de você uma presença mais atenta, uma palavra de esperança ou um gesto concreto de serviço?' },
    { reading:'Lc 2, 1-7', summary:'Jesus nasce em Belém e é colocado numa manjedoura. Os pastores recebem a notícia e vão ao encontro do Salvador.', reflection:'Contemple a humildade do nascimento de Jesus e pergunte-se como você pode abrir mais espaço para Ele na sua vida.' },
    { reading:'Lc 2, 22-35', summary:'Maria e José apresentam Jesus no Templo. Simeão e Ana reconhecem naquele menino a salvação esperada.', reflection:'Peça a graça de reconhecer a presença de Deus também nas coisas simples e nos acontecimentos cotidianos.' },
    { reading:'Lc 2, 41-52', summary:'Depois de procurar Jesus, Maria e José o encontram no Templo, entre os mestres. Jesus manifesta sua missão e permanece unido a seus pais.', reflection:'Mesmo quando Deus parece silencioso ou distante, continue procurando por Ele com perseverança e confiança.' }
  ],
  dolorosos: [
    { reading:'Lc 22, 39-46', summary:'No Horto, Jesus enfrenta a angústia e entrega sua vontade ao Pai, permanecendo fiel à missão recebida.', reflection:'Apresente a Jesus suas próprias angústias e peça a graça de confiar no Pai mesmo nos momentos difíceis.' },
    { reading:'Jo 19, 1', summary:'Jesus é submetido à flagelação antes de sua crucificação. Contemple seu sofrimento oferecido por amor.', reflection:'Diante do sofrimento de Cristo, peça um coração mais misericordioso e disposto a amar sem fugir dos sacrifícios.' },
    { reading:'Mt 27, 27-31', summary:'Jesus é humilhado e coroado de espinhos. Mesmo tratado com desprezo, permanece fiel e silencioso em sua entrega.', reflection:'Peça a Jesus humildade para não viver buscando reconhecimento e coragem para permanecer fiel quando for incompreendido.' },
    { reading:'Jo 19, 16-17', summary:'Jesus segue para o lugar da crucificação e Simão de Cirene é chamado a ajudá-lo a carregar a cruz.', reflection:'Quem está carregando uma cruz perto de você? Peça a graça de perceber e ajudar concretamente quem precisa.' },
    { reading:'Jo 19, 25-30', summary:'Jesus é crucificado e entrega sua vida ao Pai. Sua morte manifesta o amor levado até o fim.', reflection:'Contemple o amor de Cristo e entregue a Ele aquilo que mais pesa em seu coração neste momento.' }
  ],
  gloriosos: [
    { reading:'Jo 20, 1-18', summary:'As mulheres encontram o túmulo vazio e recebem o anúncio de que Jesus ressuscitou. A tristeza dá lugar à esperança.', reflection:'Onde você precisa deixar a esperança de Cristo vencer o desânimo e o medo?' },
    { reading:'At 1, 6-11', summary:'Jesus sobe ao Céu e envia seus discípulos para continuar sua missão, com a promessa de sua presença.', reflection:'Peça coragem para viver sua fé no mundo e assumir sua parte na missão que Cristo confia à Igreja.' },
    { reading:'At 2, 1-4', summary:'O Espírito Santo desce sobre os discípulos e os fortalece para anunciar o Evangelho a todos.', reflection:'Peça ao Espírito Santo que renove sua fé e lhe dê coragem para testemunhar Jesus com alegria.' },
    { reading:'Lc 1, 46-55 (meditação mariana relacionada)', summary:'No Magnificat, Maria louva a Deus por suas maravilhas e reconhece a misericórdia divina que alcança todas as gerações. A passagem convida a contemplar a esperança e a ação de Deus na vida de Maria.', reflection:'Contemple Maria como sinal de esperança e peça que ela o conduza cada vez mais para seu Filho.' },
    { reading:'Ap 12, 1-6 (meditação mariana relacionada)', summary:'O sinal da mulher revestida de sol e coroada de estrelas é contemplado pela tradição cristã como imagem de esperança e vitória de Deus. A passagem não narra diretamente a coroação de Maria; serve aqui como apoio à meditação mariana.', reflection:'Peça perseverança para buscar a santidade sem perder de vista a esperança da vida eterna.' }
  ],
  luminosos: [
    { reading:'Mt 3, 13-17', summary:'Jesus é batizado no Jordão. O Pai manifesta seu amor pelo Filho e o Espírito Santo aparece sobre Ele.', reflection:'Recorde que sua vida também é chamada a pertencer a Deus e peça a graça de viver sua vocação com fidelidade.' },
    { reading:'Jo 2, 1-11', summary:'Nas Bodas de Caná, Maria apresenta a necessidade dos noivos a Jesus, e Ele realiza seu primeiro sinal.', reflection:'Apresente a Jesus, pelas mãos de Maria, aquilo que falta em sua vida e confie na ação de Deus.' },
    { reading:'Mc 1, 14-15', summary:'Jesus anuncia a chegada do Reino de Deus e chama as pessoas à conversão e à fé no Evangelho.', reflection:'Que mudança concreta Deus está pedindo de você hoje? Peça um coração disponível para a conversão.' },
    { reading:'Mt 17, 1-8', summary:'Jesus se transfigura diante dos discípulos. Sua glória se manifesta e o Pai convida a escutá-lo.', reflection:'Em meio à rotina, reserve espaço para escutar Jesus e deixar que sua presença ilumine suas decisões.' },
    { reading:'Lc 22, 14-20', summary:'Na Última Ceia, Jesus entrega aos discípulos o sinal da Eucaristia e antecipa sua entrega por amor.', reflection:'Agradeça a Jesus por sua entrega e peça um coração que reconheça a grandeza da Eucaristia.' }
  ]
};

const prayers = {
  father:'Pai nosso, que estais nos céus, santificado seja o vosso nome; venha a nós o vosso Reino; seja feita a vossa vontade, assim na terra como no céu. O pão nosso de cada dia nos dai hoje; perdoai-nos as nossas ofensas, assim como nós perdoamos a quem nos tem ofendido; e não nos deixeis cair em tentação, mas livrai-nos do mal. Amém.',
  hail:'Ave, Maria, cheia de graça, o Senhor é convosco; bendita sois vós entre as mulheres e bendito é o fruto do vosso ventre, Jesus. Santa Maria, Mãe de Deus, rogai por nós, pecadores, agora e na hora de nossa morte. Amém.',
  glory:'Glória ao Pai, e ao Filho, e ao Espírito Santo. Como era no princípio, agora e sempre. Amém.',
  fatima:'Ó meu Jesus, perdoai-nos, livrai-nos do fogo do inferno, levai as almas todas para o céu e socorrei principalmente as que mais precisarem da vossa misericórdia.',
  salve:'Salve, Rainha, Mãe de misericórdia, vida, doçura e esperança nossa, salve! A vós bradamos, os degredados filhos de Eva. A vós suspiramos, gemendo e chorando neste vale de lágrimas. Eia, pois, advogada nossa, esses vossos olhos misericordiosos a nós volvei; e depois deste desterro mostrai-nos Jesus, bendito fruto do vosso ventre. Ó clemente, ó piedosa, ó doce sempre Virgem Maria. Rogai por nós, Santa Mãe de Deus, para que sejamos dignos das promessas de Cristo. Amém.'
};

const $ = id => document.getElementById(id);
const settings = JSON.parse(localStorage.getItem('santoTercoSettings') || '{}');
const day = new Date().getDay();
const savedProgress = JSON.parse(localStorage.getItem('santoTercoProgress') || 'null');
const selectedKey = savedProgress?.themeKey || sessionStorage.getItem('selectedMystery');
const theme = selectedKey && Object.values(DATA).find(x => x.key === selectedKey) || DATA[day];

if(settings.theme === 'dark') document.documentElement.classList.add('forced-dark');
if(settings.theme === 'light') document.documentElement.classList.add('forced-light');
if(settings.animations === false) document.documentElement.classList.add('reduce-motion');
Object.entries({'--mystery':theme.color,'--mystery-dark':theme.dark,'--mystery-soft':theme.soft,'--mystery-pale':theme.pale})
  .forEach(([k,v]) => document.documentElement.style.setProperty(k,v));

$('weekday').textContent = new Intl.DateTimeFormat('pt-BR',{weekday:'long'}).format(new Date());
$('theme-name').textContent = theme.name;

/* Estado atual. Cada mudança de oração gera um novo snapshot. */
const defaultState = {section:'intro',phase:'father',introHail:0,decade:0,hail:0};
let state = savedProgress?.state ? {...defaultState,...savedProgress.state} : {...defaultState};
let history = Array.isArray(savedProgress?.history) ? savedProgress.history : [];
let confirmationArmed = false;
let confirmationTimer = null;

/* Áudio do pequeno toque de madeira. O volume vem das Configurações. */
const beadSound = new Audio('assets/audio/conta-madeira.wav');
beadSound.preload = 'auto';
beadSound.volume = Math.max(0, Math.min(1, Number(settings.volume ?? 22) / 100));

let parishPlayer = null;
let speechActive = false;

function playBeadSound(){
  if(settings.beadSound === false) return;
  try { beadSound.currentTime = 0; beadSound.play().catch(()=>{}); } catch(e) {}
}

function currentAudioFile(){
  if(state.section === 'salve') return parishAudio.salve;
  if(state.section === 'decade') return parishAudio[state.phase] || null;
  if(state.section === 'intro') return parishAudio[state.phase === 'hail' ? 'hail' : state.phase] || null;
  return null;
}

const img = (src,alt,cls='') => `<img class="prayer-image ${cls}" src="assets/images/${src}" alt="${alt}" loading="eager" decoding="async" onerror="this.style.display='none';">`;
const framed = (src,alt,cls='') => img(`framed/${src}`,alt,cls);
const imageNames = {
  gozosos:['anunciacao','visitacao','nascimento','apresentacao','encontro'],
  dolorosos:['agonia','flagelacao','coroacao','cruz','crucificacao'],
  gloriosos:['ressurreicao','ascensao','pentecostes','assuncao','coroacao'],
  luminosos:['batismo','bodas','reino','transfiguracao','eucaristia']
};
function currentImage(){ return `${theme.key}-${state.decade+1}-${imageNames[theme.key][state.decade]}.webp`; }

/* ================================================================
   PROGRESSO — salva o estado completo, não apenas o número do mistério.
   ================================================================ */
function saveProgress(){
  if(settings.saveProgress === false){
    localStorage.removeItem('santoTercoProgress');
    return;
  }
  localStorage.setItem('santoTercoProgress', JSON.stringify({
    state,
    history,
    themeKey: theme.key,
    updatedAt: Date.now()
  }));
}

function clearProgress(){
  localStorage.removeItem('santoTercoProgress');
  sessionStorage.removeItem('selectedMystery');
}

function snapshot(){ return JSON.parse(JSON.stringify(state)); }
function restoreSnapshot(value){ state = {...defaultState,...value}; }

function progress(){
  let p;
  if(state.section === 'intro'){
    p = state.phase === 'father' ? 2 : state.phase === 'hail' ? 3 + state.introHail : 7;
  }else if(state.section === 'decade'){
    p = 8 + state.decade * 18 + (state.phase === 'father' ? 0 : state.phase === 'hail' ? 1 + state.hail : state.phase === 'glory' ? 12 : state.phase === 'fatima' ? 15 : 18);
  }else if(state.section === 'salve') p = 98;
  else p = 100;
  $('progress').style.width = Math.min(100,Math.round(p)) + '%';
  $('progress-text').textContent = Math.min(100,Math.round(p)) + '%';
}

function render(transition=false){
  const m = theme.m[state.decade];
  if(transition){
    const el = document.querySelector('.prayer-stage');
    el.classList.remove('page-transition');
    void el.offsetWidth;
    el.classList.add('page-transition');
  }

  $('visual-wrap').innerHTML = '';
  let label='',title='',subtitle='',count='',text='',button='Amém';

  if(state.section === 'intro'){
    if(state.phase === 'father'){
      label='Preparação'; title='Pai-Nosso'; subtitle='Antes dos cinco mistérios'; count='Oração inicial'; text=prayers.father;
      $('visual-wrap').innerHTML=`<div class="simple-art image-art">${img('credo-frame.webp','Imagem do Credo')}</div>`;
    }else if(state.phase === 'hail'){
      label='Preparação'; title='Ave-Maria'; subtitle=['Em honra a Deus Pai','Em honra a Deus Filho','Em honra ao Espírito Santo'][state.introHail-1]; count=`${state.introHail}/3`; text=prayers.hail;
      $('visual-wrap').innerHTML=`<div class="simple-art ihs-art"><img class="ihs-icon" src="assets/images/ostensorio-ihs.svg" alt="Ostensório com IHS"></div>`;
    }else{
      label='Preparação'; title='Glória ao Pai'; subtitle='Ao Pai, ao Filho e ao Espírito Santo'; count='Oração inicial'; text=prayers.glory;
      $('visual-wrap').innerHTML=`<div class="simple-art ihs-art"><img class="ihs-icon" src="assets/images/ostensorio-ihs.svg" alt="Ostensório com IHS"></div>`;
    }
  }else if(state.section === 'decade'){
    if(state.phase === 'father'){
      label=`${state.decade+1}º Mistério`; title=m[0]; subtitle=m[1]; count='Pai-Nosso'; text=prayers.father;
      $('visual-wrap').innerHTML=`<div class="mystery-art">${framed(currentImage().replace('.webp','-frame.webp'),m[0])}</div>`;
    }else if(state.phase === 'hail'){
      label=m[0]; title='Ave-Maria'; subtitle='Contemple este mistério com Maria'; count=`${state.hail}/10`; text=prayers.hail;
      $('visual-wrap').innerHTML=`<div class="mystery-art">${framed(currentImage().replace('.webp','-frame.webp'),m[0])}<span class="count-pill">${state.hail}/10</span></div>`;
    }else if(state.phase === 'glory'){
      label='Conclusão da dezena'; title='Glória ao Pai'; subtitle='Ao Pai, ao Filho e ao Espírito Santo'; count='Glória'; text=prayers.glory;
      $('visual-wrap').innerHTML=`<div class="mystery-art">${framed(currentImage().replace('.webp','-frame.webp'),m[0])}</div>`;
    }else if(state.phase === 'fatima'){
      label='Oração de Fátima'; title='Ó meu Jesus'; subtitle='Permaneça alguns instantes em oração'; count=''; text=prayers.fatima;
      $('visual-wrap').innerHTML=`<div class="simple-art image-art">${framed('o-meu-jesus-frame.webp','Jesus Misericordioso')}</div>`;
    }else{
      label='Mistério concluído'; title=state.decade<4?`Próximo: ${theme.m[state.decade+1][0]}`:'Quinto mistério concluído'; subtitle=state.decade<4?'Prepare o coração para continuar.':'Prepare-se para a oração final.'; count=`${state.decade+1}/5`; text=state.decade<4?'Ao tocar em continuar, iniciaremos a próxima dezena.':'Ao tocar em continuar, seguiremos para a Salve Rainha.'; button=state.decade<4?'Próximo mistério':'Salve Rainha';
      $('visual-wrap').innerHTML=`<div class="simple-art transition-art"><div class="transition-symbol">✦</div></div>`;
    }
  }else if(state.section === 'salve'){
    label='Oração final'; title='Salve, Rainha'; subtitle='Conclusão do Santo Terço'; count=''; text=prayers.salve; button='Amém';
    $('visual-wrap').innerHTML=`<div class="simple-art image-art">${framed('salve-rainha-frame.webp','Nossa Senhora para a Salve Rainha')}</div>`;
  }else{
    label='Sinal da Cruz'; title='Em nome do Pai, do Filho e do Espírito Santo'; subtitle='Encerramos esta oração reunidos em um só Deus'; count=''; text='Amém.'; button='Concluir';
    $('visual-wrap').innerHTML=`<div class="simple-art"><div class="creed-art state-art"><span class="cross-small"></span><span class="light-ray r1"></span><span class="light-ray r2"></span><span class="light-ray r3"></span></div></div>`;
  }

  $('label').textContent=label;
  $('title').textContent=title;
  $('subtitle').textContent=subtitle;
  $('counter').textContent=count;
  $('prayer-type').textContent=label;
  $('prayer-count').textContent=count;
  $('prayer-text').textContent=text;
  $('amen').textContent=button;
  $('previous-prayer').disabled = history.length === 0;
  progress();
  saveProgress();
}

/* ================================================================
   AVANÇAR
   ================================================================ */
function advance(){
  playBeadSound();
  history.push(snapshot());

  if(state.section === 'intro'){
    if(state.phase === 'father'){ state.phase='hail'; state.introHail=1; }
    else if(state.phase === 'hail'){
      if(state.introHail < 3) state.introHail++;
      else state.phase='glory';
    }else{
      state.section='decade'; state.phase='father';
    }
  }else if(state.section === 'decade'){
    if(state.phase === 'father'){ state.phase='hail'; state.hail=1; }
    else if(state.phase === 'hail'){
      if(state.hail < 10) state.hail++;
      else state.phase='glory';
    }else if(state.phase === 'glory') state.phase='fatima';
    else if(state.phase === 'fatima') state.phase='mysteryDone';
    else if(state.phase === 'mysteryDone'){
      if(state.decade < 4){ state.decade++; state.phase='father'; state.hail=0; }
      else state.section='salve';
    }
  }else if(state.section === 'salve') state.section='closing';
  else finish();

  confirmationArmed=false;
  render(true);
}

/* O segundo clique confirma o avanço quando a opção estiver ligada.
   Evita o confirm() nativo e deixa a experiência mais bonita no celular. */
$('amen').onclick=()=>{
  if(!settings.confirmAdvance){ advance(); return; }
  if(!confirmationArmed){
    confirmationArmed=true;
    clearTimeout(confirmationTimer);
    $('amen').textContent='Confirmar →';
    $('amen').classList.add('confirming');
    confirmationTimer=setTimeout(()=>{
      confirmationArmed=false;
      $('amen').textContent='Amém';
      $('amen').classList.remove('confirming');
    },2200);
    return;
  }
  clearTimeout(confirmationTimer);
  advance();
};

/* Volta para a oração imediatamente anterior, sem sair do Terço. */
$('previous-prayer').onclick=()=>{
  if(!history.length) return;
  const previous=history.pop();
  restoreSnapshot(previous);
  confirmationArmed=false;
  clearTimeout(confirmationTimer);
  $('amen').classList.remove('confirming');
  render(true);
};

/* Volta para a Home e pergunta se o fiel quer guardar o ponto. */
$('home-button').onclick=()=>{
  const wantsToSave = confirm('Deseja salvar o ponto onde você está para continuar depois?\n\nOK = salvar e sair\nCancelar = sair sem salvar');
  if(wantsToSave) saveProgress();
  else clearProgress();
  location.href='index.html';
};

function stopPrayerSpeech(){
  if ('speechSynthesis' in window) window.speechSynthesis.cancel();
  speechActive = false;
  const button = $('speak-button');
  if (button) { button.textContent = '🗣️'; button.setAttribute('aria-label','Ouvir esta oração'); button.classList.remove('is-speaking'); }
}

function speakCurrentPrayer(){
  if (!('speechSynthesis' in window) || !('SpeechSynthesisUtterance' in window)) {
    sheet('Leitura em voz alta','<p class="sheet-text">Este navegador não disponibiliza leitura em voz alta. Tente abrir o app no Chrome ou em um dispositivo compatível.</p>');
    return;
  }
  if (speechActive || window.speechSynthesis.speaking || window.speechSynthesis.paused) {
    stopPrayerSpeech();
    return;
  }
  const text = ($('prayer-text')?.textContent || '').trim();
  if (!text) return;
  const prefs = JSON.parse(localStorage.getItem('santoTercoSettings') || '{}');
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'pt-BR';
  utterance.rate = Number(prefs.voiceRate || 0.9);
  utterance.pitch = 1;
  const voices = window.speechSynthesis.getVoices();
  const chosen = voices.find(v => v.voiceURI === prefs.voiceURI) || voices.find(v => /^pt[-_]BR$/i.test(v.lang)) || voices.find(v => /^pt/i.test(v.lang));
  if (chosen) utterance.voice = chosen;
  const button = $('speak-button');
  speechActive = true;
  if (button) { button.textContent = '■'; button.setAttribute('aria-label','Parar leitura'); button.classList.add('is-speaking'); }
  utterance.onend = utterance.onerror = () => { speechActive = false; if(button){button.textContent='🗣️';button.setAttribute('aria-label','Ouvir esta oração');button.classList.remove('is-speaking');} };
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(utterance);
}

function sheet(title,body){
  $('sheet-content').innerHTML=`<h2 class="sheet-title">${title}</h2>${body}`;
  $('backdrop').hidden=false;
  requestAnimationFrame(()=>$('sheet').classList.add('open'));
}
$('close').onclick=closeSheet;
$('backdrop').onclick=closeSheet;
function closeSheet(){
  $('sheet').classList.remove('open');
  setTimeout(()=>$('backdrop').hidden=true,260);
}

$('meditate').onclick=()=>{
  if(state.section !== 'decade'){
    sheet('Meditar', '<p class="sheet-text">A meditação fica disponível quando você estiver contemplando um dos cinco mistérios.</p>');
    return;
  }

  const m=theme.m[state.decade];
  const data=meditationData[theme.key]?.[state.decade];
  if(!data){
    sheet('Meditar — '+m[0], '<p class="sheet-text">A meditação deste mistério ainda está sendo preparada.</p>');
    return;
  }

  const readingId='bible-reading-'+state.decade;
  const reflectionId='reflection-'+state.decade;
  const body=`
    <div class="meditation-head">
      <span class="meditation-kicker">${theme.name}</span>
      <h3>${m[0]}</h3>
    </div>

    <div class="meditation-reading">
      <div class="meditation-reading-head">
        <div>
          <strong>📖 Palavra de Deus</strong>
          <small>${data.reading}</small>
        </div>
        <button class="sheet-small-button" id="reveal-reading" type="button">Mostrar leitura</button>
      </div>
      <div class="reading-reveal" id="${readingId}" hidden>
        <p><strong>Passagem bíblica:</strong> ${data.reading}</p>
        <p class="reading-note">Abaixo está uma síntese em palavras próprias para ajudar na meditação. Ela não substitui a leitura bíblica integral.</p>
        <p class="reading-summary">${data.summary}</p>
        <p class="reading-note">Deseja ler o texto integral? Procure a referência na sua Bíblia. A transcrição da edição Bíblia Ave-Maria poderá ser incluída quando houver autorização para uso no aplicativo.</p>
      </div>
    </div>

    <div class="meditation-reflection">
      <div class="meditation-reading-head">
        <div>
          <strong>💭 Para meditar</strong>
          <small>Uma breve reflexão para sua oração</small>
        </div>
        <button class="sheet-small-button" id="reveal-reflection" type="button">Revelar</button>
      </div>
      <div class="reading-reveal" id="${reflectionId}" hidden>
        <p class="reflection-text">${data.reflection}</p>
      </div>
    </div>
  `;

  sheet('Meditar', body);

  setTimeout(()=>{
    const revealReading=$('reveal-reading');
    const reading=$(`${readingId}`);
    const revealReflection=$('reveal-reflection');
    const reflection=$(`${reflectionId}`);

    revealReading?.addEventListener('click',()=>{
      reading.hidden=!reading.hidden;
      revealReading.textContent=reading.hidden?'Revelar leitura':'Ocultar leitura';
      revealReading.classList.toggle('is-open',!reading.hidden);
      if(!reading.hidden) reading.scrollIntoView({behavior:settings.animations===false?'auto':'smooth',block:'nearest'});
    });

    revealReflection?.addEventListener('click',()=>{
      reflection.hidden=!reflection.hidden;
      revealReflection.textContent=reflection.hidden?'Revelar':'Ocultar';
      revealReflection.classList.toggle('is-open',!reflection.hidden);
      if(!reflection.hidden) reflection.scrollIntoView({behavior:settings.animations===false?'auto':'smooth',block:'nearest'});
    });

  },0);
};
$('speak-button').onclick=speakCurrentPrayer;
window.addEventListener('pagehide', stopPrayerSpeech);
$('prayers').onclick=()=>sheet('Orações',`<p class="sheet-text"><strong>Pai-Nosso</strong><br>${prayers.father}</p><p class="sheet-text"><strong>Ave-Maria</strong><br>${prayers.hail}</p><p class="sheet-text"><strong>Glória</strong><br>${prayers.glory}</p>`);

function recordPrayerCompletion(){
  // Guarda apenas a data do dia em que um Terço foi concluído.
  // O mesmo dia nunca é contado duas vezes.
  const key='santoTercoPrayedDays';
  const today=new Date();
  const dateKey=`${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
  let days=[];
  try{ days=JSON.parse(localStorage.getItem(key)||'[]'); }catch(e){ days=[]; }
  if(!Array.isArray(days)) days=[];
  if(!days.includes(dateKey)) days.push(dateKey);
  days.sort();
  // Mantém um histórico enxuto; datas antigas não são necessárias para a sequência atual.
  if(days.length>370) days=days.slice(-370);
  localStorage.setItem(key,JSON.stringify(days));
}

function finish(){
  recordPrayerCompletion();
  clearProgress();
  $('celebration').hidden=false;
  setTimeout(()=>$('finish').focus(),600);
}
$('finish').onclick=()=>location.href='index.html';

render();
