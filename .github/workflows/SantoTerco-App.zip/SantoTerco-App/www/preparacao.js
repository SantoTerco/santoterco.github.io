/* Cores e preferências das páginas de preparação do Santo Terço.
   Respeita o mistério escolhido pelo usuário ou, na ausência dele, o mistério do dia. */
(function(){
  const themes={
    gozosos:['#87A98A','#52775A','#DFEADF','#F1F7F1'],
    gloriosos:['#7696B4','#4E6D8A','#DDE7F0','#F0F5F9'],
    dolorosos:['#9B7182','#765161','#EEE3E7','#F8F1F4'],
    luminosos:['#D6B45D','#927A32','#F2E8C9','#FBF7EA']
  };
  const byDay=['gloriosos','gozosos','dolorosos','gloriosos','luminosos','dolorosos','gozosos'];
  let selected=sessionStorage.getItem('selectedMystery');
  if(!themes[selected]) selected=byDay[new Date().getDay()];
  const [color,dark,soft,pale]=themes[selected];
  const root=document.documentElement;
  root.style.setProperty('--mystery',color);
  root.style.setProperty('--mystery-dark',dark);
  root.style.setProperty('--mystery-soft',soft);
  root.style.setProperty('--mystery-pale',pale);
  const settings=(()=>{try{return JSON.parse(localStorage.getItem('santoTercoSettings')||'{}')}catch(e){return {}}})();
  if(settings.theme==='dark') root.classList.add('forced-dark');
  if(settings.theme==='light') root.classList.add('forced-light');
  if(settings.animations===false) root.classList.add('reduce-motion');
  const names={gozosos:'Mistérios Gozosos',gloriosos:'Mistérios Gloriosos',dolorosos:'Mistérios Dolorosos',luminosos:'Mistérios Luminosos'};
  document.querySelectorAll('[data-mystery-name]').forEach(el=>el.textContent=names[selected]);
})();
