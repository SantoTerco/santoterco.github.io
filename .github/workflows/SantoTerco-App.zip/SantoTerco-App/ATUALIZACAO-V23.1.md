# Santo Terço — atualização V23.1

## Alterações
1. Corrigido o estado da Home após a conclusão do Terço:
   - botão principal passa a mostrar “Concluído” quando o Terço foi rezado no dia;
   - link textual “Rezar novamente” aparece abaixo;
   - se houver oração em andamento, a ação “Continuar” tem prioridade.
2. Novo fluxo depois do Sinal da Cruz:
   - Oferecimento do Santo Terço;
   - intenções pessoais (campo opcional, guardado apenas na sessão);
   - Credo;
   - fluxo normal do Terço.
3. Nova oração de agradecimento antes da Salve Rainha.
4. Texto da Salve Rainha atualizado conforme fornecido.
5. Novas páginas, scripts e estilos incluídos no cache offline.

## Arquivos principais alterados
- `www/index.html`
- `www/home-v14.js`
- `www/inicio.js`
- `www/credo.html`
- `www/terco.js`
- `www/style.css`
- `www/sw.js`
- `www/oferecimento.html` (novo)
- `www/intencoes.html` (novo)
- `www/preparacao.js` (novo)
- `www/preparacao.css` (novo)

## Gerar o APK
Substitua no repositório GitHub o arquivo `SantoTerco-App.zip` pelo ZIP atualizado e mantenha o workflow de compilação na pasta `.github/workflows/`, com extensão `.yml`.
