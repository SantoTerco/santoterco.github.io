# Como gerar o APK do Santo Terço

## Uma vez só (instalar)
1. Node.js (versão LTS): https://nodejs.org
2. Android Studio: https://developer.android.com/studio (instale com as opções padrão)

## Passo a passo
Abra o terminal na pasta SantoTerco-App (no VS Code: Terminal > Novo Terminal) e rode, um por vez:

    npm install
    npx cap add android
    npx cap sync
    npx cap open android

O Android Studio vai abrir o projeto. Espere terminar de carregar (barra no canto de baixo) e então:

**Build > Build Bundle(s) / APK(s) > Build APK(s)**

Quando terminar, clique em "locate" na notificação. O arquivo é o app-debug.apk.
Copie para o celular e instale (permita "instalar apps desconhecidos").

## Se você mudar o código
Edite os arquivos dentro da pasta `www` e rode:

    npx cap sync

Depois gere o APK de novo.

## Para distribuir publicamente pelo site
O app-debug.apk serve para testar. Para distribuir, gere um APK assinado:
Build > Generate Signed Bundle / APK > APK. Guarde bem a chave (keystore) que criar.
